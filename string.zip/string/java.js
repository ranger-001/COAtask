function transformString() {
    const inputString = document.getElementById('inputString').value;
    const length = inputString.length;
    let transformedString = '';

    if (length % 15 === 0) {
        // Perform both operations: reverse and then replace each character with its ASCII code
        const reversedString = inputString.split('').reverse().join('');
        transformedString = reversedString.split('').map(char => char.charCodeAt(0)).join(' ');
    } else if (length % 5 === 0) {
        // Replace each character with its ASCII code
        transformedString = inputString.split('').map(char => char.charCodeAt(0)).join(' ');
    } else if (length % 3 === 0) {
        // Reverse the entire string
        transformedString = inputString.split('').reverse().join('');
    } else {
        // If none of the conditions are met, return the original string
        transformedString = inputString;
    }

    document.getElementById('output').innerText = transformedString;
}
